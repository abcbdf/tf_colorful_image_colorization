import tensorflow as tf
import numpy as np
import os
import time
from model import Model
from load_image import *
import utils
import cv2

tf.app.flags.DEFINE_integer("batch_size", 20, "batch size for training")
tf.app.flags.DEFINE_integer("num_epochs", 20, "number of epochs")
tf.app.flags.DEFINE_float("keep_prob", 0.5, "drop out rate")
tf.app.flags.DEFINE_boolean("is_train", True, "False to inference")
tf.app.flags.DEFINE_string("data_dir", "./MNIST_data", "data dir")
tf.app.flags.DEFINE_string("train_dir", "./train", "training dir")
tf.app.flags.DEFINE_integer("inference_version", 0, "the param version for inference")
FLAGS = tf.app.flags.FLAGS

def shuffle(X, shuffle_parts = 1):
    chunk_size = len(X) / shuffle_parts
    chunk_size = int(chunk_size)
    shuffled_range = range(chunk_size)

    X_buffer = np.copy(X[0:chunk_size])

    for k in range(shuffle_parts):
        np.random.shuffle(list(shuffled_range))
        for i in range(chunk_size):
            X_buffer[i] = X[k * chunk_size + shuffled_range[i]]

        X[k * chunk_size:(k + 1) * chunk_size] = X_buffer

    return X

def train_epoch(model, sess, train_list):
    loss = 0.0
    st, ed, times = 0, FLAGS.batch_size, 0
    #print(len(train_list))
    while st < len(train_list) and ed <= len(train_list):
    	train_batch = train_list[st : ed]
    	rg_list = []
    	black_list = []
    	for image_dir in train_batch:
    		img, img_black = load_image(image_dir)
    		rg_list.append(img[:, :, 1:])
    		black_list.append(img_black)
    	feed = {model.x_: black_list, model.y_: rg_list, model.keep_prob: FLAGS.keep_prob}
    	loss_, _ = sess.run([model.loss, model.train_op], feed)
    	loss += loss_
    	st, ed = ed, ed+FLAGS.batch_size
    	times += 1
    loss /= times
    return loss

def valid_epoch(model, sess, valid_list):
    loss = 0.0
    st, ed, times = 0, FLAGS.batch_size, 0
    while st < len(valid_list) and ed <= len(valid_list):
       valid_batch = valid_list[st : ed]
       rg_list = []
       black_list = []
       for image_dir in valid_batch:
       	img, img_black = load_image(image_dir)
       	#cv2.cvtColor(img * 255, cv2.COLOR_LAB2RGB)
       	rg_list.append(img[:, :, 1:])
       	black_list.append(img_black)
       #cv2.cvtColor(color_list[0] * 255, cv2.COLOR_LAB2RGB)
       feed = {model.x_: black_list, model.y_: rg_list, model.keep_prob: FLAGS.keep_prob}
       #cv2.cvtColor(color_list[0] * 255, cv2.COLOR_LAB2RGB)
       loss_, output = sess.run([model.loss, model.output], feed)
       #cv2.cvtColor(color_list[0] * 255, cv2.COLOR_LAB2RGB)
       if st == 0:
       	output_reshape = np.reshape(output[0], [64, 64, 2])
       	output_con = np.zeros([64, 64, 3])
       	output_con[:, :, 0] = black_list[0]
       	output_con[:, :, 1:] = output_reshape
       	save_LABimage(output_con , "./display/output_color.jpg")
       	#cv2.cvtColor(color_list[0] * 255, cv2.COLOR_LAB2RGB)
       	real_con = np.zeros([64, 64, 3])
       	real_con[:, :, 0] = black_list[0]
       	real_con[:, :, 1:] = rg_list[0]
       	save_LABimage(real_con , "./display/real_color.jpg")
       	save_image(black_list[0] , "./display/black_white.jpg")
       	print(utils.psnr(output_con * 255, real_con * 255))    
       loss += loss_
       st, ed = ed, ed+FLAGS.batch_size
       times += 1
    loss /= times
    return loss

with tf.Session() as sess:
	if not os.path.exists(FLAGS.train_dir):
	    os.mkdir(FLAGS.train_dir)
	if FLAGS.is_train:
		train_list, test_list = get_image_list()
		cnn_model = Model(is_train = True)
		# if tf.train.get_checkpoint_state(FLAGS.train_dir):
		# 	try:
		# 		cnn_model.saver.restore(sess, tf.train.latest_checkpoint(FLAGS.train_dir))
		# 	except:
		# 		tf.global_variables_initializer().run()
		# else:
		# 	tf.global_variables_initializer().run()
		tf.global_variables_initializer().run()
		pre_losses = 1e18 * 3
		best_val_loss = 1e18 * 3
		for epoch in range(FLAGS.num_epochs):
		    start_time = time.time()
		    train_loss = train_epoch(cnn_model, sess, train_list)
		    train_list = shuffle(train_list)
		    val_loss = valid_epoch(cnn_model, sess, test_list)
		    # if val_loss < best_val_loss:
		    # 	best_val_loss = val_loss
		    # 	best_epoch = epoch + 1
		    # 	test_loss = valid_epoch(cnn_model, sess, test_list)
		    # 	cnn_model.saver.save(sess, '%s/checkpoint' % FLAGS.train_dir, global_step = cnn_model.global_step)
		    epoch_time = time.time() - start_time
		    print("Epoch " + str(epoch + 1) + " of " + str(FLAGS.num_epochs) + " took " + str(epoch_time) + "s")
		    print("  learning rate:                 " + str(cnn_model.learning_rate.eval()))
		    print("  training loss:                 " + str(train_loss))
		    print("  validation loss:               " + str(val_loss))
		    #print("  best epoch:                    " + str(best_epoch))
		    #print("  test loss:                     " + str(test_loss))
	else:
		pass


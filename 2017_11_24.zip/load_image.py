import cv2
import os
import numpy as np

# img = cv2.imread("a.JPEG")
# imgblack = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# print(img.shape)
# print(imgblack.shape)

def get_image_list(train_dir = './data/'):
	image_list = []
	for dir in os.listdir(train_dir):
		image_list.append(os.path.abspath(train_dir + dir))
	length = len(image_list)
	return image_list[: int(length * 3 / 4)], image_list[int(length * 3 / 4):]
	#return image_list[: int(length)], image_list[int(length * 3 / 4):]

def load_image(image_dir, size):
	img = cv2.imread(image_dir)
	img = cv2.resize(img, (size, size))
	#imgblack = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	imglab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
	imgblack = imglab[:, :, 0]
	# print(imglab[:, :, 0] - imgblack)
	# cv2.namedWindow("a")
	# cv2.imshow("a", imgblack)
	# cv2.waitKey(0)
	# cv2.imshow("a", img)
	# cv2.waitKey(0)
	# cv2.imshow("a", cv2.cvtColor(imglab, cv2.COLOR_LAB2RGB))
	# cv2.waitKey(0)
	# cv2.imshow("a", imglab[:, :, 2])
	# cv2.waitKey(0)
	# cv2.imshow("a", imglab[:, :, 0] - imgblack)
	# cv2.waitKey(0)
	# exit()
	#print(img / 255)
	#print(imgblack / 255)
	#cv2.cvtColor(imglab, cv2.COLOR_LAB2RGB)
	# imgggg = (imglab / 255 * 255).astype(int)
	# print(imgggg - imglab)
	#cv2.cvtColor((imglab / 255 * 255).astype(np.dtype('uint8')), cv2.COLOR_LAB2RGB)
	return imglab / 255, imgblack / 255
	#return img, imgblack

def save_image(image, image_dir):
	image_temp = image * 255
	cv2.imwrite(image_dir, image_temp)

def save_LABimage(image, image_dir):
	image_temp = (image * 255).astype(np.dtype('uint8'))
	image_RGB = cv2.cvtColor(image_temp, cv2.COLOR_LAB2RGB)
	cv2.imwrite(image_dir, image_RGB)
# -*- coding: utf-8 -*-

import tensorflow as tf


class Model:
    def __init__(self,
                 is_train,
                 learning_rate=0.001,
                 learning_rate_decay_factor=0.9995):
        self.x_ = tf.placeholder(tf.float32, [None, 64, 64])
        self.y_ = tf.placeholder(tf.float32, [None, 64, 64, 2])
        self.keep_prob = tf.placeholder(tf.float32)

        x = tf.reshape(self.x_, [-1, 64, 64, 1])
        #x = tf.reshape(self.x_, [-1, 64 * 64])

        # TODO: implement input -- Conv -- ReLU -- MaxPool -- Conv -- ReLU -- MaxPool -- Linear -- loss
        conv1_weight = weight_variable([3, 3, 1, 32])
        conv1_bias = bias_variable([32])
        conv2_weight = weight_variable([3, 3, 32, 64])
        conv2_bias = bias_variable([64])
        l1_weight = weight_variable([16 * 16 * 64, 64 * 64 * 2])
        l1_bias = bias_variable([64 * 64 * 2])
        Conv1 = tf.nn.conv2d(x, conv1_weight, strides = [1, 1, 1, 1], padding = 'SAME') + conv1_bias
        ReLU1 = tf.nn.relu(Conv1)
        MaxPool1 = tf.nn.max_pool(ReLU1, ksize = [1, 2, 2, 1], strides = [1, 2, 2, 1], padding = 'SAME')
        Conv2 = tf.nn.conv2d(MaxPool1, conv2_weight, strides = [1, 1, 1, 1], padding = 'SAME') + conv2_bias
        ReLU2 = tf.nn.relu(Conv2)
        MaxPool2 = tf.nn.max_pool(ReLU2, ksize = [1, 2, 2, 1], strides = [1, 2, 2, 1], padding = 'SAME')
        MaxPool2_flat = tf.reshape(MaxPool2, [-1, 16 * 16 * 64])
        logits = tf.matmul(MaxPool2_flat, l1_weight) + l1_bias
        #        the 10-class prediction output is named as "logits"
        #logits = tf.Variable(tf.constant(0.0, shape=[100, 10]))  # deleted this line after you implement above layers

        # weight = weight_variable([64 * 64, 64 * 64 * 3])
        # bias = bias_variable([64 * 64 * 3])
        # logits = tf.nn.relu(tf.matmul(x, weight) + bias)

        y = tf.reshape(self.y_, [-1, 64 * 64 * 2])
        self.output = tf.reshape(logits, [-1, 64, 64, 2])
        self.loss = tf.reduce_mean(tf.square(logits - y))
        #self.loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=y, logits=logits)) ### This is wrong. In picture there shouldn't be softmax

        self.learning_rate = tf.Variable(float(learning_rate), trainable=False,
                                         dtype=tf.float32)
        self.learning_rate_decay_op = self.learning_rate.assign(self.learning_rate * learning_rate_decay_factor)

        self.global_step = tf.Variable(0, trainable=False)
        self.params = tf.trainable_variables()
        self.train_op = tf.train.AdamOptimizer(self.learning_rate).minimize(self.loss, global_step=self.global_step,
                                                                            var_list=self.params)

        self.saver = tf.train.Saver(tf.global_variables(), write_version=tf.train.SaverDef.V2,
                                    max_to_keep=3, pad_step_number=True, keep_checkpoint_every_n_hours=1.0)


def weight_variable(shape):  # you can use this func to build new variables
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)


def bias_variable(shape):  # you can use this func to build new variables
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)


def batch_normalization_layer(inputs, isTrain=True):
    # TODO: implemented the batch normalization func and applied it on conv and fully-connected layers
    mean, deviation = tf.nn.moments(inputs, [0, 1, 2])
    save_mean = tf.Variable(tf.zeros(mean.shape))
    save_deviation = tf.Variable(tf.ones(deviation.shape))

    gamma = weight_variable(mean.shape)
    beta = bias_variable(mean.shape)

    if isTrain:
        mean_layer = save_mean.assign(save_mean * 0.999 + mean * 0.001)
        deviation_layer = save_deviation.assign(save_deviation * 0.999 + deviation * 0.001)
        with tf.control_dependencies([mean_layer, deviation_layer]):
            inputs = gamma * (inputs - save_mean) / tf.sqrt(save_deviation + 0.001) + beta
    else:
        inputs = gamma * (inputs - save_mean) / tf.sqrt(save_deviation + 0.001) + beta
    # hint: you can add extra parameters (e.g., shape) if necessary
    return inputs